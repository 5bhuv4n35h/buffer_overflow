Link project with wsock32.lib for VC++
and with libwsock32.a for MingW.