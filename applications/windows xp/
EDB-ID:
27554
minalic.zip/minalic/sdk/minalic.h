/*
 * Function prototype declarations of the 
 * minaliclib api.
 */

void echo(char *txt);

void echoex(char *txt,int level);

char *get_config_value(char *key, char *value);
