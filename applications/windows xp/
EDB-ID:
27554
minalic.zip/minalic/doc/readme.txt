Release 2.0.0
Date 2011-04-13
Stabil version of the server.

